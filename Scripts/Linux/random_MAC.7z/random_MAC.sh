for i in {1..200}
do
openssl rand -hex 4 | sed 's/^/abcd/; s/\(....\)/\1-/g; s/.$//'   >>mac.txt
done
